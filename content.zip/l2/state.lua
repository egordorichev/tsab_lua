local state = object:extend()

function state:init()

end

function state:destroy()

end

function state:update(dt)

end

function state:draw()

end

return state